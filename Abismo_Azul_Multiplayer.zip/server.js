const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{
  let file = req.url === '/' ? '/index.html' : decodeURIComponent(req.url.split('?')[0]);
  const full = path.join(__dirname, file.replace(/^\/+/,''));
  if(!full.startsWith(__dirname)){res.writeHead(403);return res.end('Forbidden');}
  fs.readFile(full,(err,data)=>{
    if(err){res.writeHead(404);return res.end('Arquivo não encontrado');}
    const ext=path.extname(full);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});res.end(data);
  });
});
const wss = new WebSocket.Server({server});
const players = new Map(); let nextId=1;
function broadcast(){const data=JSON.stringify({type:'players',players:[...players.values()]});for(const c of wss.clients)if(c.readyState===WebSocket.OPEN)c.send(data);}
wss.on('connection',ws=>{
  const id='p'+nextId++; players.set(id,{id,x:4100,y:20,face:1,playing:false});ws.send(JSON.stringify({type:'welcome',id}));broadcast();
  ws.on('message',raw=>{try{const m=JSON.parse(raw.toString());if(m.type!=='move')return;
    const p=players.get(id);if(!p)return;
    // Validação básica dos dados enviados pelo navegador.
    if(Number.isFinite(m.x))p.x=Math.max(0,Math.min(8200,m.x));
    if(Number.isFinite(m.y))p.y=Math.max(0,Math.min(7200,m.y));
    p.face=m.face<0?-1:1;p.playing=!!m.playing;broadcast();
  }catch(_){}});
  ws.on('close',()=>{players.delete(id);broadcast();});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Abismo Azul Multiplayer em http://localhost:${PORT}`));
